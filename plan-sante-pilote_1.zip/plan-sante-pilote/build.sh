#!/usr/bin/env bash
# Chiffre source/index.html avec un mot de passe et écrit la version publiable dans site/.
# Usage :  ./build.sh "mot de passe"        (ou  STATICRYPT_PASSWORD="..." ./build.sh)
# Prérequis : Node.js 18 ou plus récent (npx télécharge StatiCrypt 3.5.4 au premier lancement).
set -euo pipefail
cd "$(dirname "$0")"
PASS="${1:-${STATICRYPT_PASSWORD:-}}"
[ -n "$PASS" ] || { echo "Mot de passe requis : ./build.sh \"mot de passe\""; exit 1; }

rm -rf site && mkdir site
npx --yes staticrypt@3.5.4 source/index.html -p "$PASS" --short -c .staticrypt.json -d site \
  --remember 7 \
  --template-title "Mon plan santé — Partenamut" \
  --template-instructions "Pilote réservé aux conseillers Partenamut. Saisissez le mot de passe qui vous a été communiqué." \
  --template-placeholder "Mot de passe" \
  --template-button "Ouvrir" \
  --template-error "Mot de passe incorrect" \
  --template-remember "Se souvenir de ce poste pendant 7 jours" \
  --template-toggle-show "Afficher le mot de passe" \
  --template-toggle-hide "Masquer le mot de passe" \
  --template-color-primary "#1158BF" \
  --template-color-secondary "#1B1F55"

# La page de saisie du mot de passe ne doit pas être indexée par les moteurs de recherche.
sed -i 's#<head>#<head><meta name="robots" content="noindex,nofollow">#' site/index.html
cp -r source/fonts site/fonts
echo "OK : site/ est prêt à être publié (index.html chiffré + fonts/)."
