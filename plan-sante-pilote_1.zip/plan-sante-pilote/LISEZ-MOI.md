# Mon plan santé — pilote vendeurs

Outil autonome d'aide à la vente (qualification, avantages de la complémentaire, simulateurs Hospitalia et Dentalia Up, récapitulatif) à utiliser en agence, face au client. Il tourne entièrement dans le navigateur : aucune donnée saisie n'est envoyée ni enregistrée (seul le nom du conseiller est gardé sur le poste).

## Contenu du dossier

- `site/` — ce qui se publie : la page chiffrée par mot de passe (`index.html`) et les polices (`fonts/`).
- `source/` — la même page en clair, éditable. **Ne jamais déposer ce dossier dans un dépôt public.**
- `build.sh` — régénère `site/` à partir de `source/` avec un mot de passe : `./build.sh "mot de passe"` (Node.js 18 ou plus récent requis).
- `.staticrypt.json` — sel de chiffrement (ce n'est pas un secret). À conserver : il permet à « Se souvenir de ce poste » de survivre aux mises à jour.
- `extras/pages.yml` — publication automatique, optionnelle (voir la fin).

## Publier sur GitHub Pages

1. Créer un dépôt GitHub. Compte gratuit : le dépôt doit être public, sans danger tant que seul le contenu de `site/` y est déposé.
2. Déposer à la racine du dépôt le **contenu** de `site/` : `index.html` et le dossier `fonts/`.
3. Settings, Pages, « Deploy from a branch », branche `main`, dossier `/ (root)`, Save.
4. Après une ou deux minutes, l'adresse (`https://<compte>.github.io/<dépôt>/`) s'affiche en haut de la page Pages.
5. Communiquer l'adresse aux conseillers, et le mot de passe par un autre canal.

Une page GitHub Pages est publique, même issue d'un dépôt privé, sauf avec GitHub Enterprise Cloud : c'est pourquoi la page est chiffrée.

## Ce que protège le mot de passe, et ce qu'il ne protège pas

- La page est chiffrée (AES-256, via StatiCrypt) et ne se déchiffre dans le navigateur qu'avec le mot de passe. Sans lui, un visiteur ne voit qu'un champ de saisie ; un mauvais mot de passe affiche une alerte du navigateur « Mot de passe incorrect ».
- C'est une barrière de pilote, pas un contrôle d'accès individuel : toute personne qui a le mot de passe peut le transmettre, il n'y a aucun journal de connexion, et retirer l'accès à quelqu'un suppose de changer le mot de passe et de republier.
- La case « Se souvenir de ce poste » garde le mot de passe (haché) 7 jours dans le navigateur : à décocher sur une tablette partagée.
- Les polices (`fonts/`) restent publiques ; elles ne contiennent rien de sensible.
- Le dossier `source/` est en clair : il ne doit pas se trouver dans un dépôt public.

## Mettre à jour

1. Modifier `source/index.html`. Les chiffres se trouvent dans le script : primes et garanties Hospitalia (`HOSPI_GRID`, `SCEN_H`, `MAT_RATE`), plafonds et primes Dentalia Up (`DENT_YEARS`, `DENT_GRID`, `SCEN_D`).
2. Lancer `./build.sh "mot de passe"` (le même mot de passe, ou un nouveau pour couper l'ancien accès).
3. Remplacer dans le dépôt les fichiers par ceux de `site/`, puis commit et push.

Primes et plafonds changent chaque année : prévoir une relecture en janvier avec le produit.

## Vue client et vue conseiller

- La page s'ouvre toujours en **Vue client** : le client peut la lire sans voir les consignes de vente.
- **Vue conseiller** (interrupteur en haut de l'écran) affiche en plus : le rappel de règle Dentalia, les paragraphes « À retenir », les invites de saisie (titulaire manquant, couverture ailleurs non justifiée, ancienneté de mutation), la durée cible de l'étape, le nom de la clinique source des estimations hospitalières (anonymisée pour le client : « une clinique bruxelloise » — à valider avec le service juridique), un rappel sur le matériel et les médicaments sans intervention de l'assurance obligatoire, et les consignes de saisie. Elle n'est jamais mémorisée. Les textes visibles par le client parlent en « nous » (Partenamut et le conseiller) et « vous » (le prospect).
- Rien de tout cela ne sort dans le PDF du récapitulatif, quelle que soit la vue.
- Pour rouvrir la barre de revue et les notes de conception : ajouter `#design` à la fin de l'adresse.

## À valider avant d'ouvrir aux vendeurs

- Points métier encore ouverts : cas cancer construit (aucun barème public), règle du 50 % sur le matériel et les médicaments (non écrite dans la brochure), suppléments à 300 % extrapolés des relevés à 200 %, franchise Hospitalia Plus à 300 %, plafond cancer 4 000 € (brochure) ou 5 000 € (page produit), exclusion « accidents de circulation » (brochure et conditions générales divergent).
- Relecture juridique des mentions « sans valeur contractuelle » et du cadre de la vente à distance ou en agence.
- Test sur la tablette utilisée en agence et avec 3 à 5 conseillers : seul Chromium a été testé, pas Safari ni iPad. Audit d'accessibilité (WCAG AA) non réalisé.
- Compte GitHub : à héberger sur un compte validé par l'IT ou la sécurité de Partenamut.

## Option : publication automatique

`extras/pages.yml` publie à chaque modification, avec le mot de passe dans un secret GitHub (`PAGE_PASSWORD`). Il suppose un dépôt **privé** (plan GitHub payant, car le dépôt contient alors `source/`) et la source Pages « GitHub Actions ». Non testé sur GitHub : à vérifier au premier lancement.
